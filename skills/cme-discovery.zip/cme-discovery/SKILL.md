---
name: cme-discovery
description: >-
  Find gaps in CME taxonomy coverage by analyzing recent vulnerabilities.
  Use when the user asks to find CME gaps or discover what entries are needed.
---

# CME Entry Discovery

Analyze recent vulnerability data from OSIDB to identify gaps in the CME taxonomy — weakness classes, mitigation strategies, or control layers that lack adequate CME coverage. Generate candidate entries and optionally submit them as proposals.

## Trigger

User asks to "find gaps in CME coverage", "review recent CVEs for new mitigations", "discover CME gaps", "what new CME entries do we need", or "analyze vulnerability trends for new controls".

## CME MCP Server

The CME MCP server at `cmetaxonomy.org/mcp` is registered as `cme-taxonomy` in the user-scope config. It provides these tools (prefixed `mcp__cme-taxonomy__` in Claude Code):

| Tool | Purpose | Key args |
|------|---------|----------|
| `get_cme_coverage_summary` | Coverage state for gap analysis | (none) |
| `list_cme_taxonomy` | Full tactic/category hierarchy | (none) |
| `search_cme` | Search entries by tactic, category, layer, keyword | `keyword`, `tactic`, `category`, `category_id`, `control_layer` |
| `get_mitigations_for_weakness` | CME entries by CWE | `cwe_id` (e.g. "CWE-119") |
| `get_mitigations_for_product` | CME entries by product | `cpe`, `purl`, `vendor`, `product`, `platform` |
| `get_mitigations_for_cvss_vector` | CME entries by CVSS vector | `cvss_vector` |
| `get_cme_entry` | Full entry by ID | `cme_id` |
| `get_verification_commands` | Verification commands for entry | `cme_id` |
| `propose_cme_entry` | Submit new entry proposal | `control_name`, `description`, `tactic`, + optional fields |
| `approve_cme_proposal` | Approve pending proposal | `cme_id` |
| `list_proposals` | List pending proposals | (none) |
| `calculate_attenuation` | CVSS attenuation for active controls | `active_cme_ids` (array) |
| `simulate_cve_risk` | Risk simulation for CVE + controls | `base_score`, `base_vector`, `active_cme_ids` |

If MCP tools are unavailable, fall back to reading entry files directly from `/Users/jwest/projects/cme/data/entries/CME-*.json`.

## Important: Lessons Learned

1. **DO NOT use the OSIDB MCP `search_flaws` tool.** It does not support date filtering. Always use the REST API via curl.

2. **OSIDB REST API auth**: Each Shell call authenticates independently. Use Kerberos negotiate for token, then Bearer token for API calls. Token fetch is ~2s.

3. **CWE hierarchy matters.** CWE-787 (Out-of-bounds Write) is a child of CWE-119 (Memory Corruption). The CME database handles this partially by listing multiple CWE IDs per entry (e.g., CME-101 lists CWE-119, CWE-120, CWE-122, CWE-787, CWE-125). When checking coverage, consider parent/child CWE relationships — a CVE with a child CWE may be covered by a CME entry that lists the parent.

4. **The `mitigation` field is a gold mine.** OSIDB flaw records include analyst-written mitigation guidance. These often describe specific defensive controls that may or may not have CME entries. Extract actionable controls from this text and cross-reference against the CME database.

5. **Taxonomy balance is intentional but has limits.** Harden dominates because most defensive controls are hardening. But Detect, Evict, and Restore are thinner and worth expanding when good candidates emerge.

6. **Category ranges have capacity.** Each category range supports ~100 entries (e.g., CME-101 through CME-199 for Kernel Hardening). Check current highest per category before proposing.

7. **New categories may be needed.** The current categories don't cover everything. If a gap doesn't fit an existing category, propose a new one with a new range prefix.

8. **Hardening guides are a rich source of controls.** Official security hardening documentation for RHEL, OpenShift, Windows, and Kubernetes describes dozens of defensive controls — many of which may not yet have CME entries.

9. **Multi-platform gap analysis has three dimensions.** (a) Controls that exist only on one platform (SELinux is Linux-only, WDAC is Windows-only, PodSecurityStandards are K8s-only). Cross-platform candidates may be possible. (b) Controls that exist on multiple platforms but have verification commands for only one — these are *platform coverage gaps* on existing entries. (c) Container-specific controls that have no CME equivalent — container escape prevention, image provenance, runtime sandboxing.

## Platforms

The CME schema supports verification commands across four platform families. When analyzing gaps and generating candidates, consider all four:

| Platform | `platform` value | Verification tool patterns |
|----------|------------------|---------------------------|
| **Linux/RHEL** | `"linux"` or `"rhel"` | `sysctl`, `grep`, `cat /proc/...`, `systemctl`, `getenforce`, `ausearch` |
| **Windows** | `"windows"` | `Get-ProcessMitigation`, `Get-BitLockerVolume`, `Get-MpComputerStatus`, `auditpol`, `secedit` |
| **Container/K8s** | `"container"` | `kubectl get ...`, `oc get ...`, `podman inspect`, `crictl inspect`, `docker inspect` |
| **Cross-platform** | `"any"` | `openssl`, `curl`, commands that work everywhere |

### Container platform specifics

Container platforms introduce a distinct control layer between OS/Kernel and Application. Container-specific controls include:

**Orchestration-level (Kubernetes/OpenShift):**
- Pod Security Standards / Pod Security Admission (Restricted, Baseline, Privileged)
- Network Policies (ingress/egress isolation)
- RBAC policies (ServiceAccount, ClusterRole binding)
- Admission controllers (OPA/Gatekeeper, Kyverno)
- Image policy (signature verification, allowed registries)
- Seccomp/AppArmor/SELinux profiles applied via security context
- Resource quotas and limit ranges
- Audit logging (API server audit policy)

**Runtime-level (container engine):**
- Read-only root filesystem
- Dropped capabilities (`--cap-drop ALL`)
- No-new-privileges flag
- User namespace remapping (rootless containers)
- Seccomp profile enforcement
- Runtime class (gVisor, Kata Containers)

**Verification command patterns:**
```bash
# Kubernetes/OpenShift
kubectl get podsecuritypolicies                    # PSP (deprecated but still deployed)
kubectl get constraint                              # OPA/Gatekeeper constraints
kubectl label --list ns <ns> | grep pod-security    # Pod Security Standards
oc get scc                                          # OpenShift SecurityContextConstraints
kubectl get networkpolicy -A                        # Network policies
kubectl auth can-i --list --as=system:serviceaccount:<ns>:<sa>

# Container runtime
podman inspect <ctr> --format '{{.HostConfig.SecurityOpt}}'
podman inspect <ctr> --format '{{.HostConfig.CapDrop}}'
crictl inspect <ctr-id> | jq '.info.runtimeSpec.linux.seccomp'
docker inspect <ctr> --format '{{.HostConfig.ReadonlyRootfs}}'
```

## Workflow

### Step 1: Get Current CME State

Call CME MCP tools to understand current coverage:

```
mcp__cme-taxonomy__get_cme_coverage_summary()
```

Returns: CWE IDs covered with entry counts, CVSS metric transitions, per-tactic and per-category counts, total entry count.

```
mcp__cme-taxonomy__list_cme_taxonomy()
```

Returns: full tactic/category hierarchy with counts and descriptions.

Build an internal map of:
- **Covered CWEs**: Set of all CWE IDs that appear in at least one CME entry
- **Thin CWEs**: CWE IDs covered by only 1-2 CME entries
- **Covered CVSS transitions**: Which metric/from/to combos exist
- **Category distribution**: Which categories have few entries

### Step 2: Fetch Recent Vulnerabilities from OSIDB

Use the script:
```bash
bash ~/.claude/skills/cme-discovery/osidb-cves.sh 90 /tmp/osidb-cves.json
```

Default window is 90 days. The user may specify a different window.

### Step 3: Five-Pronged Gap Analysis

#### 3a: CWE Coverage Gaps

For each CWE ID in the OSIDB results:
1. Check against covered CWEs from Step 1
2. Use `mcp__cme-taxonomy__get_mitigations_for_weakness(cwe_id=...)` to verify coverage depth
3. If NOT covered: flag as a gap, note the frequency
4. If covered by only 1-2 entries: flag as thin coverage
5. Prioritize by frequency — 5+ CVEs = HIGH, 2-4 = MEDIUM, 1 = LOW

#### 3b: Mitigation Text Mining

For each flaw with a non-empty `mitigation` field:
1. Extract specific defensive controls mentioned
2. For each control, search: `mcp__cme-taxonomy__search_cme(keyword=<control_term>)`
3. If no CME entry covers the control, flag as a gap candidate
4. Cluster similar mitigations — repeated recommendations signal strong gap candidates

#### 3c: Security Hardening Guide Mining (Multi-Platform)

**Hardening guide inventory:**

| Product | URL | Platform |
|---------|-----|----------|
| RHEL 10 | https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/10/html/security_hardening/index | Linux |
| RHEL 9 | https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html-single/security_hardening/index | Linux |
| OpenShift 4 Security | https://docs.openshift.com/container-platform/latest/security/index.html | Container |
| OpenShift SCC docs | https://docs.openshift.com/container-platform/latest/authentication/managing-security-context-constraints.html | Container |
| Kubernetes Pod Security Standards | https://kubernetes.io/docs/concepts/security/pod-security-standards/ | Container |
| Kubernetes Security Best Practices | https://kubernetes.io/docs/concepts/security/ | Container |
| CIS Kubernetes Benchmark | https://www.cisecurity.org/benchmark/kubernetes | Container |
| NIST SP 800-190 (Container Security) | https://csrc.nist.gov/publications/detail/sp/800-190/final | Container |
| Windows Security Baselines | https://learn.microsoft.com/en-us/windows/security/operating-system-security/device-management/windows-security-configuration-framework/windows-security-baselines | Windows |
| Windows OS Security | https://learn.microsoft.com/en-us/windows/security/operating-system-security/ | Windows |
| DISA Windows Server 2022 STIG | https://www.stigviewer.com/stig/microsoft_windows_server_2022/ | Windows |
| Defender Exploit Guard | https://learn.microsoft.com/en-us/defender-endpoint/exploit-protection-reference | Windows |

**Mining process:**

1. Fetch TOC for each guide via WebFetch. Extract section titles and one-sentence summaries.
2. Extract control topics by platform family:
   - **Linux**: sysctl, kernel params, SELinux, SSH, TLS, firewall, crypto policy
   - **Windows**: Group Policy, WDAC/AppLocker, ASR rules, Credential Guard, LAPS
   - **Container**: Pod Security Standards, Network Policies, admission controllers, image signing, seccomp profiles, rootless containers, runtime classes, SCC constraints
   - **Cross-platform**: auth, audit/logging, network isolation, TLS
3. Cross-reference: `mcp__cme-taxonomy__search_cme(keyword=<control_topic>)`
4. Deep-read top 3-5 gap candidates for verification command detail
5. Prioritize by coverage breadth (controls appearing across platform families rank highest)

**Guide selection by focus:**
- **Broad**: RHEL 10 + K8s Pod Security Standards + Windows Baselines
- **Container-focused**: OpenShift SCC + K8s Security + NIST 800-190
- **Linux-focused**: RHEL 10 + RHEL 9
- **Windows-focused**: Windows Baselines + DISA STIG
- **CWE-focused**: pick by domain — kernel CWEs → RHEL, container escape CWEs → OpenShift/K8s, endpoint CWEs → Windows
- **Limit to 2-3 guides per run**

#### 3d: Taxonomy Balance Analysis

Using coverage summary from Step 1:
1. Identify tactics with few entries (especially Detect, Evict, Restore)
2. Identify thin categories
3. Check if recent CVEs cluster in thin areas
4. Look for container-specific gaps — are there enough container-layer controls for each tactic?

#### 3e: Platform Coverage Gap Analysis

Check existing CME entries for missing platform coverage across all three platform families.

1. Use `mcp__cme-taxonomy__search_cme(keyword=...)` for cross-platform control concepts, then check each returned entry's verification commands via `mcp__cme-taxonomy__get_verification_commands(cme_id=...)`
2. Flag entries missing verification for applicable platforms:
   - Controls conceptually cross-platform (ASLR, NX, firewall, TLS, audit) → HIGH if missing any platform
   - Controls with container equivalents (seccomp, namespace isolation, capability dropping) → flag if missing container verification
   - Platform-specific controls (SELinux, WDAC, SCC) → skip, not a gap
3. Report platform gaps separately from CWE/mitigation gaps — they are enrichment opportunities on existing entries

### Step 4: ExploitIQ Enrichment

For top gap candidates, use ExploitIQ MCP tools (if available) to validate with exploitability context:

1. Pick 2-3 representative CVEs from highest-priority gaps
2. Run `analyze_cve()` or `analyze_rpm()` for each
3. Extract: attack path conditions (each = potential CME control point), verdict rationale, CVSS context
4. Map findings to CME concepts (memory safety → Kernel Hardening, network-reachable → Network Isolation, blocked by SELinux → MAC, container escape → Container Isolation)

### Step 5: Generate Candidate CME Entries

For each identified gap, draft a candidate with all CME fields:

- **control_name**: Formal name following conventions
- **description**: Technical description of the control and how it mitigates
- **tactic**: Harden, Isolate, Detect, Evict, or Restore
- **category**: Existing category or suggest new one (with category_id slug)
- **control_layer**: Network, OS/Kernel, Application, Data, Identity, or **Container/Orchestration** (suggest if needed)
- **cvss_impacts_json**: JSON array of `{metric, from, to, rationale}` — explain the mechanism
- **cwe_ids**: List of CWE IDs mitigated
- **verification_commands_json**: JSON array of `{command, expected, platform}` — include ALL applicable platforms
- **platforms**: Applicable platforms list
- **confidence**: High/Medium/Low

**Quality criteria:**
- Deterministic, verifiable CVSS attenuation with mechanistic rationale
- Distinct from existing entries
- Prefer controls addressing multiple CVEs

**Multi-platform verification commands — include all applicable:**

- **Linux**: Shell commands (sysctl, grep, cat, systemctl). Platform: `"linux"` or `"rhel"`.
- **Windows**: PowerShell cmdlets. Platform: `"windows"`.
- **Container/K8s**: kubectl, oc, podman, docker, crictl commands. Platform: `"container"`.
- **Cross-platform**: Commands that work everywhere. Platform: `"any"`.

### Step 6: Present Report and Propose

Present the full gap analysis report, then offer to submit candidates via:
```
mcp__cme-taxonomy__propose_cme_entry(
  control_name=..., description=..., tactic=...,
  category=..., category_id=..., control_layer=...,
  cvss_impacts_json=..., cwe_ids=[...],
  verification_commands_json=..., platforms=[...],
  confidence=...
)
```

## Output Format

```markdown
## CME Gap Analysis Report — <date>

**Analysis window:** <start> to <end>
**CVEs analyzed:** <N> from OSIDB (Critical + Important)
**Current CME state:** <total> entries across <categories> categories

---

### CWE Coverage Gaps

| CWE ID | Name | Frequency | CME Coverage | Priority |
|--------|------|-----------|--------------|----------|

### Mitigation Text Insights

| Control | Source CVEs | Suggested Category | Notes |
|---------|------------|-------------------|-------|

### Hardening Guide Insights

| Control | Source Guide(s) | Platform | Suggested Category | Notes |
|---------|----------------|----------|-------------------|-------|

### Platform Coverage Gaps

| CME ID | Control | Linux | Windows | Container | Suggested Verification |
|--------|---------|-------|---------|-----------|----------------------|

### Taxonomy Balance

| Tactic | Entries | Thin Categories | Container Controls |
|--------|---------|----------------|--------------------|

---

### Candidate CME Entries

#### Candidate N: <Control Name>
- **Addresses gap:** CWE-NNN — N CVEs in window
- **Tactic / Category / Control Layer**
- **Description:** ...
- **CVSS Impact:** metric:from -> to (rationale)
- **CWE Relationships:** ...
- **Verification (Linux):** `...`
- **Verification (Windows):** `...` (or N/A)
- **Verification (Container):** `...` (or N/A)

### Container-Specific Candidates

#### Candidate C1: <Control Name>
- **Source:** K8s Pod Security Standards / OpenShift SCC / NIST 800-190
- **Platforms:** Kubernetes, OpenShift, Podman
- **Description:** ...
- **CVSS Impact:** ...
- **Verification (K8s):** `kubectl ...`
- **Verification (OpenShift):** `oc ...`
- **Verification (Podman):** `podman ...`

---

### Actions

1. Submit candidates as proposals via `propose_cme_entry()`?
2. Deep-dive with ExploitIQ?
3. Adjust analysis window or scope?
```

## Script-Optimized Workflow

Scripts handle OSIDB CVE fetching and deterministic gap computation. The LLM handles mitigation text mining (NLP), hardening guide analysis (WebFetch), ExploitIQ enrichment (MCP), and candidate generation (domain expertise).

### Available Scripts

| Script | Purpose | Usage |
|--------|---------|-------|
| `osidb-cves.sh` | Fetch recent Critical/Important CVEs | `bash ~/.claude/skills/cme-discovery/osidb-cves.sh <days_back> <output.json>` |
| `gap-analysis.py` | Compute CWE gaps, taxonomy balance, platform gaps | `python3 ~/.claude/skills/cme-discovery/gap-analysis.py <cves.json> <coverage.json> <taxonomy.json> [entries_dir]` |

### Script-Optimized Steps

**Step 1**: Get CME state via MCP:
```
mcp__cme-taxonomy__get_cme_coverage_summary() → save to /tmp/cme-coverage.json
mcp__cme-taxonomy__list_cme_taxonomy() → save to /tmp/cme-taxonomy.json
```

**Step 2**: Fetch OSIDB CVEs:
```bash
bash ~/.claude/skills/cme-discovery/osidb-cves.sh 90 /tmp/osidb-cves.json
```

**Steps 3a, 3d, 3e**: Run gap computation:
```bash
python3 ~/.claude/skills/cme-discovery/gap-analysis.py \
  /tmp/osidb-cves.json /tmp/cme-coverage.json /tmp/cme-taxonomy.json \
  /Users/jwest/projects/cme/data/entries
```
Outputs `/tmp/gaps.json` with: uncovered CWEs, thin coverage, taxonomy imbalance, platform coverage gaps (including container), and mitigation keyword frequencies.

**Steps 3b, 3c, 4, 5**: Unchanged — still require LLM for NLP analysis, WebFetch, ExploitIQ, and candidate generation.
