#!/usr/bin/env python3
"""Compute CME coverage gaps from OSIDB CVE data and CME coverage summary.

Usage: python3 gap-analysis.py <cves.json> <cme_coverage.json> <cme_taxonomy.json> [entries_dir]
  cves.json:         output from osidb-cves.sh
  cme_coverage.json: output from get_cme_coverage_summary MCP tool (saved by skill)
  cme_taxonomy.json: output from list_cme_taxonomy MCP tool (saved by skill)
  entries_dir:       path to data/entries/ for platform coverage scan (optional)

Outputs: gaps.json with all computed gap analysis.
"""
import json
import os
import sys
from collections import Counter
from pathlib import Path


def load_json(path, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default if default is not None else {}


def cwe_coverage_gaps(cves, covered_cwes, cwe_entry_counts):
    """Find CWEs in recent CVEs that lack CME coverage."""
    cve_cwes = Counter()
    for flaw in cves.get("flaws", []):
        cwe = flaw.get("cwe_id")
        if cwe:
            cve_cwes[cwe] += 1

    gaps = []
    thin = []
    for cwe, count in cve_cwes.most_common():
        entries = cwe_entry_counts.get(cwe, 0)
        if entries == 0:
            gaps.append({"cwe_id": cwe, "frequency": count, "cme_entries": 0, "priority": "HIGH" if count >= 5 else "MEDIUM"})
        elif entries <= 2:
            thin.append({"cwe_id": cwe, "frequency": count, "cme_entries": entries, "priority": "LOW"})

    return {"uncovered": gaps, "thin_coverage": thin}


def taxonomy_balance(taxonomy):
    """Identify tactics and categories with few entries."""
    tactic_counts = {}
    category_details = []

    if isinstance(taxonomy, dict):
        for tactic, cats in taxonomy.get("tactics", {}).items():
            total = 0
            if isinstance(cats, list):
                for cat in cats:
                    count = cat.get("entry_count", 0)
                    total += count
                    if count <= 3:
                        category_details.append({
                            "tactic": tactic,
                            "category": cat.get("name", ""),
                            "entry_count": count,
                        })
            tactic_counts[tactic] = total

    thin_tactics = [
        {"tactic": t, "entries": c}
        for t, c in sorted(tactic_counts.items(), key=lambda x: x[1])
        if c <= 5
    ]

    return {"thin_tactics": thin_tactics, "thin_categories": category_details}


def mitigation_keywords(cves):
    """Extract actionable control keywords from mitigation text."""
    controls = Counter()
    for flaw in cves.get("flaws", []):
        mit = flaw.get("mitigation") or ""
        if not mit:
            continue
        lower = mit.lower()
        keywords = [
            ("io_uring", "restrict io_uring"),
            ("ptrace_scope", "ptrace_scope restriction"),
            ("seccomp", "seccomp filtering"),
            ("selinux", "SELinux enforcement"),
            ("ebpf", "eBPF restriction"),
            ("unprivileged_userns", "unprivileged user namespaces"),
            ("sysctl", "sysctl hardening"),
            ("apparmor", "AppArmor confinement"),
            ("namespace", "namespace isolation"),
            ("firewall", "firewall rules"),
            ("rbac", "RBAC enforcement"),
            ("tls", "TLS configuration"),
            ("certificate", "certificate validation"),
            ("container", "container isolation"),
            ("pod security", "Pod Security Standards"),
            ("network polic", "Kubernetes NetworkPolicy"),
            ("securitycontext", "security context constraints"),
            ("read-only", "read-only root filesystem"),
            ("cap_drop", "capability dropping"),
            ("no_new_priv", "no-new-privileges"),
            ("rootless", "rootless container"),
            ("image sign", "container image signing"),
            ("admission control", "admission controller"),
            ("gvisor", "gVisor runtime sandbox"),
            ("kata", "Kata Containers runtime"),
        ]
        for pattern, label in keywords:
            if pattern in lower:
                controls[label] += 1

    return [{"control": k, "frequency": v} for k, v in controls.most_common() if v >= 2]


def platform_coverage_gaps(entries_dir):
    """Scan CME entries for missing platform verification commands."""
    if not entries_dir or not os.path.isdir(entries_dir):
        return []

    gaps = []
    for entry_file in sorted(Path(entries_dir).glob("CME-*.json")):
        try:
            with open(entry_file) as f:
                entry = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            continue

        cmds = entry.get("verification_commands", [])
        if not cmds:
            continue

        platforms = set()
        for c in cmds:
            if isinstance(c, dict):
                platforms.add(c.get("platform", "").lower())

        has_linux = any(p in platforms for p in ("linux", "rhel", "any"))
        has_windows = any(p in platforms for p in ("windows", "any"))
        has_container = any(p in platforms for p in ("container", "kubernetes", "openshift", "any"))
        cme_id = entry.get("cme_id", entry_file.stem)
        name = entry.get("control_name", "")
        desc = entry.get("description", "").lower()
        name_lower = name.lower()

        cross_platform_indicators = [
            "aslr", "nx", "dep", "firewall", "tls", "password", "audit",
            "edr", "antivirus", "encryption", "logging", "mfa", "certificate",
        ]
        container_indicators = [
            "seccomp", "namespace", "capability", "sandbox", "isolation",
            "network polic", "rbac", "runtime", "rootless", "container",
        ]

        is_cross_platform = any(ind in name_lower for ind in cross_platform_indicators)
        has_container_relevance = any(
            ind in name_lower or ind in desc for ind in container_indicators
        )

        entry_gaps = {
            "cme_id": cme_id, "name": name,
            "has_linux": has_linux, "has_windows": has_windows,
            "has_container": has_container,
        }

        flagged = False
        if is_cross_platform and has_linux and not has_windows:
            entry_gaps["missing"] = entry_gaps.get("missing", []) + ["windows"]
            flagged = True
        if is_cross_platform and has_windows and not has_linux:
            entry_gaps["missing"] = entry_gaps.get("missing", []) + ["linux"]
            flagged = True
        if has_container_relevance and not has_container:
            entry_gaps["missing"] = entry_gaps.get("missing", []) + ["container"]
            flagged = True

        if flagged:
            gaps.append(entry_gaps)

    return gaps


def main():
    cves_path = sys.argv[1]
    coverage_path = sys.argv[2]
    taxonomy_path = sys.argv[3]
    entries_dir = sys.argv[4] if len(sys.argv) > 4 else None

    cves = load_json(cves_path)
    coverage = load_json(coverage_path)
    taxonomy = load_json(taxonomy_path)

    # Build CWE coverage map from the coverage summary
    covered_cwes = set()
    cwe_entry_counts = {}
    for item in coverage.get("cwe_coverage", []):
        cwe = item.get("cwe_id", "")
        count = item.get("entry_count", 0)
        if cwe:
            covered_cwes.add(cwe)
            cwe_entry_counts[cwe] = count

    result = {
        "analysis_window": cves.get("window_start", ""),
        "total_cves_analyzed": cves.get("total", 0),
        "cwe_gaps": cwe_coverage_gaps(cves, covered_cwes, cwe_entry_counts),
        "taxonomy_balance": taxonomy_balance(taxonomy),
        "mitigation_keywords": mitigation_keywords(cves),
        "platform_gaps": platform_coverage_gaps(entries_dir),
    }

    output_path = Path(cves_path).parent / "gaps.json"
    with open(output_path, "w") as f:
        json.dump(result, f, indent=2)

    # Print summary
    uncov = len(result["cwe_gaps"]["uncovered"])
    thin = len(result["cwe_gaps"]["thin_coverage"])
    plat = len(result["platform_gaps"])
    mit = len(result["mitigation_keywords"])
    print(f"Gap analysis complete: {uncov} uncovered CWEs, {thin} thin, {plat} platform gaps, {mit} mitigation keywords")
    print(f"Output: {output_path}")


if __name__ == "__main__":
    main()
