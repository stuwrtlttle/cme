#!/usr/bin/env bash
set -euo pipefail
# Fetch recent Critical/Important CVEs from OSIDB for gap analysis.
# Usage: bash osidb-cves.sh <days_back> <output.json>
#   days_back: number of days to look back (default: 90)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/osidb-auth.sh"

DAYS="${1:-90}"
OUTPUT="${2:-/tmp/osidb-cves.json}"

# macOS vs Linux date
WINDOW_START=$(date -u -v-${DAYS}d +%Y-%m-%dT00:00:00Z 2>/dev/null \
  || date -u -d "$DAYS days ago" +%Y-%m-%dT00:00:00Z)

TOKEN=$(get_osidb_token)

curl -s -H "Authorization: Bearer $TOKEN" \
  "${OSIDB_BASE_URL}/osidb/api/v1/flaws?impact__in=CRITICAL,IMPORTANT&reported_dt__gte=${WINDOW_START}&limit=200&include_fields=cve_id,title,cve_description,mitigation,impact,cwe_id,cvss_scores" \
  | jq --arg since "$WINDOW_START" '{
    window_start: $since,
    total: .count,
    flaws: [.results[]? | {
      cve_id, title,
      description: .cve_description,
      mitigation,
      impact,
      cwe_id,
      rh_cvss3_vector: ([.cvss_scores[]? | select(.issuer == "RH" and .cvss_version == "V3")] | first | .vector),
      rh_cvss3_score: ([.cvss_scores[]? | select(.issuer == "RH" and .cvss_version == "V3")] | first | .score)
    }],
    cwe_distribution: ([.results[]? | .cwe_id] | group_by(.) | map({cwe: .[0], count: length}) | sort_by(-.count)),
    impact_distribution: ([.results[]? | .impact] | group_by(.) | map({impact: .[0], count: length}))
  }' > "$OUTPUT"

echo "Fetched $(jq '.total' "$OUTPUT") CVEs to $OUTPUT (window: $WINDOW_START)"
